# Changelog

Toutes les modifications notables de ce projet sont documentées dans ce fichier.

Le format est basé sur [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/),
et ce projet suit le [versionnage sémantique](https://semver.org/lang/fr/).

## [1.2.0] - 2026-06-07

### Corrigé
- **Priorité de chargement inversée** : la carte lisait le `localStorage` en
  premier et ne consultait jamais les entités Home Assistant. La config pouvait
  diverger d'un appareil à l'autre (une modification sur mobile n'était pas vue
  sur le PC). Les entités HA sont désormais la source de vérité ; `localStorage`
  n'est plus qu'un cache d'amorçage.
- **Chunks périmés non purgés** : après une sauvegarde plus courte que la
  précédente, des fragments obsolètes restaient dans les entités `input_text`.
  Ils sont maintenant vidés à chaque sauvegarde.
- **Troncature silencieuse** : une config dépassant la capacité des entités
  (10 × 250 caractères) était tronquée sans avertissement, rendant le
  rechargement impossible. Un garde-fou bascule désormais sur `localStorage` et
  journalise un avertissement explicite.
- **Validation au rechargement** : la config reconstruite depuis HA est validée
  (`JSON.parse`) avant d'être retenue ; une donnée corrompue ne fait plus planter
  la carte et déclenche le repli sur le cache local.
- **Accès `localStorage` protégés** : `getItem`/`setItem` sont encapsulés dans
  des try/catch (Safari navigation privée et quota plein lèvent une exception).

### Ajouté
- Fichier `LICENSE` (MIT) jusque-là absent du dépôt.
- Ce `CHANGELOG.md`.
- Clé `homeassistant` minimale dans `hacs.json`.

### Modifié
- Cohérence du dépôt : toutes les références internes pointent désormais vers le
  dépôt réel `Acidburn1824/tarification`.
- `setup-github.sh` aligné sur la version 1.2.0.

## [1.1.0] - antérieur

- Première version publique avec éditeur visuel Lovelace, support ZLinky/Linky
  TIC, Tempo, EJP, multi-plages, saisonnalité et jours fériés.
