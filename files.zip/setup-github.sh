#!/bin/bash
# ============================================
# Script de mise en place du dépôt GitHub
# Widget Tarification pour Home Assistant / HACS
# ============================================

REPO="tarification"
USER="Acidburn1824"
VERSION="v1.2.0"

echo "🔧 Initialisation du dépôt ${REPO}..."
echo ""

# Vérifier que git est configuré
if [ -z "$(git config --global user.name)" ]; then
    echo "⚠️  Configurez d'abord git :"
    echo "   git config --global user.name \"Votre Nom\""
    echo "   git config --global user.email \"votre@email.com\""
    echo ""
fi

# Init repo
git init
git add .
git commit -m "Release ${VERSION} - corrections persistance + cohérence repo"

# IMPORTANT: HACS nécessite un tag de version valide
git tag -a ${VERSION} -m "Version 1.2.0 - persistance HA fiabilisée"

echo ""
echo "✅ Dépôt local prêt !"
echo ""
echo "════════════════════════════════════════════"
echo "  📋 ÉTAPES À SUIVRE"
echo "════════════════════════════════════════════"
echo ""
echo "1️⃣  Si le dépôt n'existe pas encore sur GitHub :"
echo "   → https://github.com/new"
echo "   → Nom : ${REPO}"
echo "   → Public ✓"
echo "   → NE PAS cocher 'Add a README' (on l'a déjà)"
echo ""
echo "2️⃣  Liez et poussez :"
echo ""
echo "   git remote add origin https://github.com/${USER}/${REPO}.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo "   git push origin ${VERSION}"
echo ""
echo "3️⃣  IMPORTANT - Créer la Release (obligatoire pour HACS) :"
echo ""
echo "   → https://github.com/${USER}/${REPO}/releases/new"
echo "   → Tag : ${VERSION}"
echo "   → Title : ${VERSION}"
echo "   → Glissez-déposez le fichier widget-tarification.js"
echo "   → Cliquer 'Publish release'"
echo ""
echo "4️⃣  Dans HACS :"
echo "   → HACS → Frontend → ⋮ → Dépôts personnalisés"
echo "   → URL : https://github.com/${USER}/${REPO}"
echo "   → Catégorie : Lovelace"
echo "   → Installer"
echo ""
echo "5️⃣  Ajouter la carte :"
echo "   → Modifier un dashboard → + Ajouter une carte"
echo "   → Chercher 'Widget Tarification'"
echo "   → Ou en YAML : type: custom:widget-tarification"
echo ""
echo "🎉 C'est tout !"
